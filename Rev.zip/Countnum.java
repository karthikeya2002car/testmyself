
class Countnum{
public static void main(String[] args)
{
int num=12345,count=0,rem=0;
while(num>0)
{
rem=num%10;
if(rem>0)
{
count+=1;
}
num/=10;
}
System.out.println(count);
}
//write a program to print the count of a number........
}