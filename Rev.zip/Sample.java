public class Sample {
    public static void main(String[] args) {
        
        int[] a={27,9,8,5,3,1,11};
        for(int i=0;i<a.length;i++)
        {
            boolean flag=true;
            for(int j=2;j<a[i];j++)
            {
                if(a[i]%j==0)
                {
                    flag=false;
                    break;
                }
            }
            if(flag)
            {
                System.out.println(a[i]);
            }
        }
        
        
    }
}
