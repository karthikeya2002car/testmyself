//write a program to print the sum of even or odd digits in a number.........
class EvenOddDig
{
public static void main(String[] args)
{
int num=123691,sum=0,sum1=0,rem=0;
while(num>0)
{
rem=num%10;
if(rem%2==0)
{
sum+=rem;
}
if(rem%2!=0)
{
sum1+=rem;
}
num/=10;
}
System.out.println(sum1+"odd number");
System.out.println(sum+"even number");
}
}


