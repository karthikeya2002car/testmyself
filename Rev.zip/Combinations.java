class Combinations
{
    public static void main(String[] args)
    {
       String s1="JAVA IS EASY";
       String s2="";
      char[] ch=s1.toCharArray();
}
}