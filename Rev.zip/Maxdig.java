class Maxdig {
    public static void main(String[] args)
    {
        int num=9274789,rem=0,m=0;
        while(num>0)
        {
            rem=num%10;
            if(rem>m)
            {
                m=rem;
            }
            num/=10;
        }
        System.out.println(m);
    }
    
}
