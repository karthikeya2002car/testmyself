import java.util.Scanner;
class Armstrongrange {
    public static void main(String[] args)
    {
       Scanner sc=new Scanner(System.in); 
       int start=sc.nextInt();
       int end=sc.nextInt();
       sc.close();
       for(int i=start;i<=end;i++)
       {
        int rem=0,sum=0,temp,n;
        temp=i;
        while(temp>0)
        {
            rem=temp%10;
            n=rem*rem*rem;
            sum=sum+n;
            temp/=10;
        }
       
        if(i==sum)
        {
            System.out.println("Armstrong "+sum);
           
        }
    }
        //write a program to print prime number....
    
}
}