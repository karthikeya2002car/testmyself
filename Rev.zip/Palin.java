//day2.....
//write a program to print a number is palindrome or not.....
class Palin{
public static void main(String[] args)
{
int num=121,rem=0,rev=0,copy=num;
while(num>0)
{
rem=num%10;
rev=rev*10+rem;
num/=10;
}
if(copy== rev)
{
System.out.println("the number is palindrome "+rev);
}
else
{
System.out.println("the number is not palindrome");
}
}
}