//write a program to print palindrome numbers in a given range......
class Npalin
{
public static void main(String[] args)
{
int rem=0,rev=0;
for(int num=1;num<=200;num++)
{
while(num>0)
{
rem=num%10;
rev=rev*10+rem;
num/=10;
}
if(rev==num)
{
System.out.println("is palindrome");
}
else
{
System.out.println("not");
}
//error check once.....!!!!
}
}
}
