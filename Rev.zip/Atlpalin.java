//write a program to print next palindrome.......
import java.util.Scanner;
class Atlpalin {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number:");
        int n=sc.nextInt();
        sc.close();
        for(int i=n+1;;i++)
        {
            if(isPal(i))
            {
                System.out.println(i);
                break;
            }
        }
        
}
public static boolean isPal(int n)
{
    int num=n, rev=0,rem=0;
    while(num>0)
    {
        rem=num%10;
        rev=rev*10+rem;
        num/=10;
    }
    if(rev==n)
    {
        return true;
    }
    else{
        return false;
    }
} 
}