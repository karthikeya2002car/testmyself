
//day2....
//write a program to print last three palindrome numbers in a give range.....
class L3
{
public static void main(String[] args)
{
int rem=0,rev=0,count=0,s;
for(int i=100;i>0;i--)
{
    s=i;
while(s>0)
{
rem=s%10;
rev=rev*10+rem;
s/=10;
}
if(i==rev)
{
count=count+1;
if(count<=3){
System.out.println(rev);
}
}
/*else
{
System.out.println("not");
}*/
rev=0;
}
}
}

