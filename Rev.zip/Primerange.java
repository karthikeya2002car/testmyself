import java.util.Scanner;
class Primerange {
    public static void main(String[] args)
    {  
        Scanner sc=new Scanner(System.in);
        System.out.println("please enter the starting number: ");
        int start =sc.nextInt();
        System.out.println("enter the end number: ");
        int end=sc.nextInt(); 
        sc.close();
        for(int i=start;i<=end;i++)
        {
            Primerange p=new Primerange();
            if(p.isPrime(i))
            {
                System.out.println(i+" is a Prime number");
            }
        }
}
public boolean isPrime(int n)
{
    int num=n;
    for(int i=2;i<num/2;i++)
    {
        if(num%i==0) return false;
    }
    { return true;
    }

}
}