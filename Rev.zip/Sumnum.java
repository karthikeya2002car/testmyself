class Sumnum
{
public static void main(String[] args)
{
int num=12345,rem=0,sum=0;
while(num>0)
{
rem=num%10;
sum+=rem;
num/=10;
}
System.out.println(sum);
}
//write a program to print the sum of digits in a number.....
}