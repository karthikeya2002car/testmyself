//day2.....
//write a program to reverse a number....
class Rev{
public static void main(String[] args)
{
int num=12345,rev=0,rem=0;
while(num>0)
{
rem=num%10;
rev=rev*10+rem;
num/=10;
}
System.out.println(rev);
}
}