//write a program to print a smallest digit in a number....
class Mindig
{
public static void main(String[] args)
{
int rem=0,num1=9;
for(int num=9347412;num>0;num/=10)
{
rem=num%10;
if(rem<num1)
{
num1=rem;
}
}
System.out.println(num1);
}
}