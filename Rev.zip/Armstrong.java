//write a program to print number is Armstrong or  not......
import java.util.Scanner;
class Armstrong {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        sc.close();
        int rem=0,sum=0,n,copy=num;
        while(num>0)                    /*int count=0;
                                            while(num>0)
                                            {
                                                count++;
                                                num/=10;
                                            } 
                                                */
        {
            rem=num%10;
            n=rem*rem*rem;
            sum+=n;
            num/=10;
        }
        /*int fact=1;
         * for(int i=1;i<=count;i++)
         * {
         * fact=fact+rem;
         * }
         * sum=sum+fact;
         */
        if(copy==sum)
        {
            System.out.println("Armstrong number");
        }
        else{
            System.out.println("not");
        }
    }
    
}
