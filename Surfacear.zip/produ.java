import java.util.Scanner;
public class produ {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the n value");
        int n=sc.nextInt();
        int mul=1;
        sc.close();
        for(int i=1;i<=n;i++)
        {
            mul*=i;
        }
        System.out.println("the product of "+n+" is "+mul);
    }
    
}
