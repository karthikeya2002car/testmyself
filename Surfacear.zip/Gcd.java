import java.util.Scanner;
public class Gcd 
{
    public static void main(String[] args)
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        sc.close();
        int n=0,temp=0;
        if(a<b) n=a;
        else n=b;
        for(;n>0;n--)                                       /*public static int gcd(int a, int b) {
            while (((a > 0) && (b > 0))) {
              if ((a > b)) {
                a = (a % b);
              } else {
                b = (b % a);
              }
            }
            if ((a == 0)) {
              return b;
            } else {
              return a;
            }
            }  
            public static void main(String[] args) {
            int a = new Scanner(System.in);
            int b = new Scanner(System.in);
            System.out.println(GCD.gcd(a, b));
            } */
        {
            if(a%n==0 & b%n==0)
            {
                temp=n;
                break;
                //System.out.println(temp);
            }
        }
        System.out.println(temp);
    }
}
