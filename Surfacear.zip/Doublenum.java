import java.util.Scanner;
class Doublenum {
    public static void main(String... args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("please enter the number to double: ");
        System.out.println(doubleTheNumber(sc.nextInt()));
    }
    public static int doubleTheNumber(int num1)
    {
        int dob=2*num1;
        return dob;
    }
    
}
