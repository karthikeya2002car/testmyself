import java.util.Scanner;

class cubnum {
     public static void main(String... args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("please enter the number: ");
        System.out.println(cubeNumber(sc.nextInt()));
    }
    public static int cubeNumber(int num1)
    {
        int dob=num1*num1*num1;
        return dob;
    
}
}
