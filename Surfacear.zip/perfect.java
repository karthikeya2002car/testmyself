import java.util.Scanner;

class perfect {
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int s;
   int sum=0;
   sc.close();
    for (int i=1;i<=n;i++)
    {
        s=n%i;
        if(s==0&i!=n)
        {  
            sum=sum+i;
        }
    }
    System.out.println(sum);  
    if(sum==n)
    {
        System.out.println("Perfect number");
    }
    else
    {
        System.out.println("not");
    }
}
}
