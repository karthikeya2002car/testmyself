import java.util.Scanner;

public class Nieven {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        int i=sc.nextInt();
        int n,d=0,copy=i,s=0;
        boolean g=true;
        sc.close();
        if(i<=0)
        {
            System.out.println("please enter the number above 0");
        }
        while(i>0){
            n=i%10;
            d+=n;
            i/=10;
        }
        s=copy/d;
        for(int j=2;j<s;j++)
        {
            if(s%j==0)
            {
                g=false;
                System.out.println("not nieven");
                break;
            }
        }
        if(g) System.out.println("Is Nieven");
}
}