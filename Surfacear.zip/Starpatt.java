import java.util.Scanner;

class Starpatt {
    public static void main(String[] args)
    { 
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        sc.close();
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=i;j++)//comparing the j value with i value ,so that loop iterations are based on i value.
            {
                if(j==1 | i==j | i==n){//also able to print only triangle with continus value and also hallow triangle.
                System.out.print("*");
                }
                else
                {
                    System.out.print(" ");
                }
                
            }
            
            System.out.println();
        }

    
}
}
