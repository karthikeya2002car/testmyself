import java.util.Scanner;

class countdi {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number:");
        int c=sc.nextInt();
        int count=0;
        sc.close();
        for(;c>0;)
        {
            count++;
            c/=10;
        }
        System.out.println(count);
    }
}
