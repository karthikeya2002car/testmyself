import java.util.Scanner;

class Strong {
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int total=0,copy=n;
    sc.close();
    while(n>0){
    int s=n%10;
    int sum=1;
    for(int i=1;i<=s;i++)
    {
        sum*=i;
    }
    //System.out.println(sum);
    total+=sum;
    n/=10;
    }
    if(copy==total)
    {
        System.out.println("Strong");
    }
    else
    {
        System.out.println("not");
    }
}
}
