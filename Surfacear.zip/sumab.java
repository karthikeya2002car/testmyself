import java.util.Scanner;

public class sumab {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the end value");
        int n=sc.nextInt();
        System.out.println("enter the start value");
        int s=0;
        for (int b=sc.nextInt();b<=n;b++)
        {

            s+=b;
            System.out.println(b+" + "+s+" = "+s);
        }
        
}
}