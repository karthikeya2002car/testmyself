import java.util.Scanner;
public class lcm {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        int i=sc.nextInt();
        int j=sc.nextInt();
        int n=1;
        sc.close();
        while(true)
        {
        if(n%i==0 & n%j==0)//rem*i+n==0 & rem*j+n==0
        {
            break;
        }
        n++;
    }
    /*int n=a>b?a:b;
    int i=n; 
    while(true)
     * {
     * if(n%a==0 & n%b==0)
     * n=n+i;
     * }
     * s.o.p(n);
     */
    System.out.println(n);
    }
}
