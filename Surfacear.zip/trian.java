import java.util.Scanner;
class train{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int a=0,b=0,c=0;
        for(a=1;a<=n/2;a++){
        for(b=1;b<n/2;b++)
        {
            c=n-a-b;
        if(c*c==(a*a)+(b*b))
        {
            System.out.println(a+" and "+b+" and "+c);
            break;
        }
    }
    }
}
}
