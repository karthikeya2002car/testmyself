import org.omg.CORBA.SystemException;

class sample
{
    public static void main(String arr[])
    {
        int d=5;
      for(int i=1;i<=5;i++)
      {
        if(i==1)
        {
            for(int j=1;j<=5;j++)
            {
                System.out.print(j+"\t");
            }
        }
        else
        {
        for(int j=d;j<=5;j++)
        {
            System.out.print(j+"\t");
        }
    
        for(int j=1;j<=d-1;j++)
        {
            System.out.print(j+"\t");
        }
        d--;
    }
        
       /*  for(int j=d;j<=5;j++)
        {
            System.out.print(j);
        }*/
    
       
        System.out.println();

    }
}
}
