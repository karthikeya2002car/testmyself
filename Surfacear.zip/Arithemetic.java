import java.util.Scanner;
class Arithemetic {
    public static void main(String... args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("please enter the values for substraction: ");
        System.out.println(substractNumber(sc.nextInt(), sc.nextInt()));
        System.out.println("please enter the values for multiplication: ");
        System.out.println(multiplyNumber(sc.nextInt(), sc.nextInt()));
        System.out.println("please enter the values for division: ");
        System.out.println(divideNumber(sc.nextInt(), sc.nextInt()));
        System.out.println("please enter the values for finding the reminder: ");
        System.out.println(findReminder(sc.nextInt(), sc.nextInt()));

    }
    public static int substractNumber(int num1,int num2)
    {
        int sub=num1-num2;
        return sub;
    }
    public static int multiplyNumber(int num1,int num2)
    {
        int mul=num1*num2;
        return mul;
    }
    public static int divideNumber(int num1,int num2)
    {
        int divd=num1/num2;
        return divd;
    }
    public static int findReminder(int num1,int num2)
    {
        int rem=num1%num2;
        return rem;
    }
    
}
