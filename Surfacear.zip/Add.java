
class Add {
    public static void main(String... args)
    {
       
        System.out.println(Add.galacticAddition(125678,9876543210L));
    }
    public static long galacticAddition(long num1,long num2)
    {
        long sum1=num1+num2;
        return sum1;
    }
    
}
