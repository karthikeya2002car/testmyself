public class SumOfAllPrimeAndSumPrime {
    public static void main(String[] args) {
        int start=24,end=120,sum=0;
        boolean b1=false;

        for(int i=start;i<end;i++)
        {
          b1= prime(i);
          if(b1==true)
          {
            sum+=i;
          }
        }
        b1=prime(sum);
        if(b1==true)
        {
            System.out.println("the sum "+sum+" is a prime");
        }
        else{
            System.out.println("not a prime "+sum);
        }
        
    }
    public static boolean prime(int n)
    {
        for(int i=2;i<=n/2;i++)
        {
            if(n%i==0) return false;
        }
        return true;
    }
}
