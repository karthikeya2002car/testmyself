import java.util.Scanner;

class numtri {
    public static void main(String[] args)
    { 
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        sc.close();
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=i;j++)// i value is initially 1 and will be incremented so we get numbers in order.
            {
                System.out.print(j);
            }
            System.out.println();
        }
    
}
}
/*1
 * 12
 * 123
 * 1234
 * 12345
 */
