public class Tester {
    
    public static String test(byte b) {
        return "Byte ";
    }
    
    public static String test(char c) {
        return "Char ";
    }
    
    public static String test(int i) {
        return "Int ";
    }
    
    public static void main(String[] args) {
        //byte b = 0;
        //char c = 'A';
        //int a=29,d=3;
       // System.out.println(a<<15);
        //System.out.print(test(true  ? b : c));
        //System.out.print(test(false ? b : c));
        //System.out.print(test(true  ? 0 : 'A'));
        // System.out.print(test(false ? 'A' : (byte)0));
    }
}