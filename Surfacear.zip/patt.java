class patt {
    public static void main(String[] args)
    {
        int n=5,j,x=1,s=n+1;
        for(int i=1;i<=5;i++)
        {
            if(i%2!=0){
            for( j=x;j<=50;j++)
            {
                System.out.print(j);
            }
            }
            else
            {
                for(int k=s;k<=10;k++)
                {
                    System.out.print(k);
                }
            }
            x=s;
         System.out.println();
        }

    }
    
}
