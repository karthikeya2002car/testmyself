import java.util.Scanner;

class dectobin {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int bin=0;
        int i=1;
        sc.close();
        while(n>0)
        {
            int rem=n%2;
            bin=bin+rem*i;
            i=i*10;
            n/=2;
        }
        System.out.println(bin);
    
}
}
