import java.util.Scanner;
class Elect {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter the current reading:");
        double reading=sc.nextDouble();
        System.out.println("Please enter the previous reading:");
        double prereading=sc.nextDouble();
        double re=prereading-reading;
        System.out.println("The price chart per unit is:");
        System.out.println("For 200 units - Free");
        System.out.println("For more than 200 units - Rs:3/-");
        System.out.println("For more than 250 units - Rs:5/-");
        System.out.println("For more than 300 units - Rs:7/-");
        System.out.println("For more than 400 units - Rs:11/-");
        sc.close();
        if(re<0)
        {
            System.out.println("Caution! Your meter is not working properly");
        }
        if(re <= 200 & re >=0)
        {
            System.out.println("Your Current is Free "+re);
        }
        if(re > 200)
        {
            double ch=re-200;
            if(ch<=100)
            {
            System.out.println("Please enter the charges for more than 200 units");
            double charge=sc.nextDouble();
            double to=re*charge;
            System.out.println("Please enter the pending charge of last month");
            double pending=sc.nextDouble();
            if(pending!=0)
            {
            double tot=to+pending+10/100;
            System.out.println(tot);
            }
            else
            {
                System.out.println("Your total bill is: "+to+pending);
            }
            }
            if(ch>100 & ch<=150)
            {
            System.out.println("Please enter the charges for more than 350 units");
            double charge=sc.nextDouble();
            double to=re*charge;
            System.out.println("Please enter the pending charge of last month");
            double pending=sc.nextDouble();
            if(pending!=0)
            {
                double tot=to+pending+10/100;
                System.out.println("Your total electricity bill is:"+tot);
            }
            else
            {
                System.out.println("Your total bill is: "+to+pending);
            }
            }
            if(ch>150 & ch<= 200)
            {
            System.out.println("Please enter the charges for more than 400 units");
            double charge=sc.nextDouble();
            double to=re*charge;
            System.out.println("Please enter the pending charge of last month");
            double pending=sc.nextDouble();
            if(pending!=0)
            {
                double tot=to+pending+10/100;
                System.out.println("Your total electricity bill is:"+tot);
            }
            else
            {
                System.out.println("Your total bill is: "+to+pending);
            }
            }
            if(ch>200 & ch<=400)
            {
            System.out.println("Please enter the charges for more than 600 units");
            double charge=sc.nextDouble();
            double to=re*charge;
            System.out.println("Please enter the pending charge of last month");
            double pending=sc.nextDouble();
            if(pending!=0)
            {
                double tot=to+pending+10/100;
                System.out.println("Your total electricity bill is:"+tot);
            }
            else
            {
                System.out.println("Your total bill is: "+to+pending);
            }
            }
            if(ch>400)
            {
                System.out.println("Caution! You are not allowed to use more than 600 units");
            }
            
        }
}
}