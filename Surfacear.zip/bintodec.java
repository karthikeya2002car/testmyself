import java.util.Scanner;

class bintodec {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int bin=0;
        int i=1;
        sc.close();
        while(n!=0)
        {
            int rem=n%10;
            bin=bin+rem*i;
            i=i*2;
            n/=10;
        }
        System.out.println(bin);
    
}
}
