import java.util.Random;
class Player{
    int health;
    int strength;
    int attack;

    public Player(int health,int strength,int attack)
    {
        this.health=health;
        this.strength=strength;
        this.attack=attack;
    }
}
public class MagicalArena {
    static Random random=new Random();
    public static int rollingDies(){
        return random.nextInt(6)+1;
    }
    public static void fight(Player attckPlayer,Player defendPlayer)
    {
        int attackerDie=rollingDies();
        int defenderDie=rollingDies();

        int attackdamage=attckPlayer.attack*attackerDie;
        int defendStrenght=defendPlayer.strength*defenderDie;
        int damage=Math.max(0,attackdamage-defendStrenght);
        defendPlayer.health-=damage;

        System.out.println("Attack Rolling Dies "+attackerDie+" Defender Rolling Dies "+defenderDie);
        System.out.println("Attack Damage "+attackdamage+" defend Strength "+defendStrenght);
       
        System.out.println("Defender health moved from "+damage+" to "+defendPlayer.health);
        
       
    }
    public static void clinchFight(Player player1,Player player2)
    {
        while((player1.health > 0) && (player2.health > 0))
        {
            if(player1.health < player2.health)
            {
                fight(player1, player2);
                if(player2.health <= 0)
                {
                    System.out.println("Player1 Wins");
                    break;
                }
                fight(player2, player1);
                if(player1.health <= 0)
                {
                    System.out.println("Player2 Wins");
                    break;
                }
            }
            else{
                fight(player2, player1);
                if(player1.health <= 0)
                {
                    System.out.println("Player2 Wins");
                    break;
                }
                fight(player1, player2);
                if(player2.health <= 0) 
                {
                    System.out.println("Player1 Wins");
                    break;
                }
            }
        }
    }
    public static void main(String[] args) {
        Player player1=new Player(50, 5, 10);
        Player player2=new Player(100, 10, 5);
        clinchFight(player1,player2);
    }
}
