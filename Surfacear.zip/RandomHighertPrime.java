import java.util.Scanner;
//print the 3rd highest prime number in given range....
public class RandomHighertPrime {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int start=sc.nextInt();
        int end=sc.nextInt();
        int count=0,temp=0;
        for(int i=start;i<=end;i++)
        {
            if(isPrime(i))
            {
                count++;
                temp=i;
            }
        }
        //pending ...
    }
    public static boolean isPrime(int num)
    {
        for(int i=2;i<num/2;i++)
        {
            if(num%i==0)return false;
        }
        return true;
    }
    
}
