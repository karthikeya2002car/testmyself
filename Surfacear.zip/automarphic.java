import java.util.Scanner;

class automarphic {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        int i=sc.nextInt();
        int n,d=1,copy=i;
        sc.close();
        n=i*i;
        while(i>0){
            d*=10;//used to divide the i based on length of numner(eg:- for 2 digit number we divide with 100 ,if 1 digit 10,3 digit 1000).
            i/=10;
        }
        int s=n%d;
        if(s==copy)
        {
            System.out.println("Automarphic");
        }
        else
        {
            System.out.println("get lost");
        }
}
}
