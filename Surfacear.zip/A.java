class A 
{
public static void main(String[] args) 
{
int rem=0,rev=0,count=0,s;
for(int i=1;i<=100;i++)
{
    s=i;
while(s>0)
{
rem=s%10;
rev=rev*10+rem;
s/=10;
}
if(i==rev)
{
    count=count+1;
    if(count%2==0)
    System.out.println("palindrome "+rev);
}
rev=0;//used to re-iinitialize the rev to zero. if not the rev will be same for every iterartion.....
}
}
}
