public class BinerayAndSort {
    
        public static void main(String[] args) {
            int []a= {-5,3,0,1,4,-15};
            int key=3;
            for(int i=0;i<a.length;i++)
            {
                for(int j=0;j<a.length-1-i;j++)
                {
                    if(a[j]>a[j+1])
                    {
                        int temp=a[j];
                        a[j]=a[j+1];
                        a[j+1]=temp;
                    }
                }
            }
          int num=sort1(a,key);
          System.out.println(prime2(num)+" "+num+" is a prime number");
        }
          public static boolean prime2(int num)
          {
          for(int i=2;i<num;i++)
          {
            if(num%i==0) return false;
          }
          return true;
        }
        
            //System.out.println(Arrays.toString(a));
            public static int  sort1(int[] a,int key)
            {
                int start=0,end=a.length-1;
                while(start<=end)
                {
                    int mid=((start+end)/2);
                    if(key==a[mid]) return a[mid];
                    else if(key<a[mid])end=mid-1;
                    else if(key>a[mid])start=mid+1;
                    else
                    {
                        System.out.println(-1);
                    }
                }
                return -1;
            }
    
    
}
