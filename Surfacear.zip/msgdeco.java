import java.util.Scanner;

class msgdeco {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println(decodeCharacter('A'));
    }
    public static int decodeCharacter(char var)
    {
        char decoder=var;
        return decoder;
    
    
}
}
