

import java.util.Scanner;
import java.lang.Math;
class P{
    public double calculateSurfaceArea(double radius)
    {
        double a=4*Math.PI*Math.pow(radius,2);
        return a;
    }
}
public class Surfacear 
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        P explore=new P();
       System.out.printf("%.2f", explore.calculateSurfaceArea(sc.nextDouble()));
       sc.close();
    }
    
}
