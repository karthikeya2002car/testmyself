import java.util.Scanner;

class dimond {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int d=1;
        int f=n-1;
        sc.close();
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=f;j++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=d;j++)
            {
                if(i==n | j==1 |j==d){
                System.out.print("#");
                }
                else
                {
                    System.out.print("-");
                }
            }
            System.out.println();
            if(i<=n/2)
            {
                d+=2;
                f--;
            }
            else
            {
                d-=2;
                f++;
            }
            
        }
    
}
}

