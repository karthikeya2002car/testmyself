import java.util.Scanner;
class Sumdig {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        int num=sc.nextInt();
        int copy=num,res,sum=0;
        while(num!=0)
        {
            res=num%10;//the entire number is divided with 10 so that the reminder will be the last digit of the number!!!!
            sum+=res;//sum is initially 0 so for every iteration res is added to sum....
            num/=10;//here we are eleminating the last digit of the number so to get the next digit in a number.....
        }
        System.out.println(sum);
    }
    
}
