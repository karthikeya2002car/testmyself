import java.util.Scanner;
class Magic {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        int i=sc.nextInt();
        int copy=i,rev=0,sum=0,a,n;
        sc.close();
        while(i>0)
        {
            n=i%10;
            sum+=n;
            i/=10;
        }
        a=sum;
        int d=a;
        while(a!=0){
            n=a%10;
            rev=rev*10+n;
            a/=10;
        }
        if(d*rev==copy)
        {
            System.out.println("Magic");
        }
        else
        {
            System.out.println("not");
        }
    }  
}
