public class ScopeAdd {
    public static void main(String[] args) {
        int[] a={1,5,7,9,11};
        int b=16;
        int j=1,i=j-1,k=j+1,count=0,o=0,sum=0;
        while(k<=a.length)
        {
            sum=a[i];
            count++;
            if(sum==b)
            {
                System.out.print(count);
            }
            else{
                sum+=a[i];
                i=i+1;
            }
            
        }
        
    }
    
}
