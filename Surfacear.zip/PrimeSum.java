public class PrimeSum {
    public static void main(String[] args) {
        String s1="34567";
        String s2="";
        for(int i=0;i<s1.length();i++)
        {
            int num=s1.charAt(i)-'0';

            if(isPrime(num))
            {
                s2+=num;
            }
        }
        System.out.println(s2);
}
public static boolean isPrime(int num)
{
    if(num<=1)
    return false;
    for(int i=2;i<=num/2;i++)
    {
        if(num%i==0)
        return false;
    }
    return true;
}
}
