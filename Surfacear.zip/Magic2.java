public class Magic2 {
    public static void main(String[] args) {
        
    int num=325,sum=0,res=0;

    while(num>0)
    {
        int rem=num%10;
        sum+=rem;
        num/=10;
    }
    if(sum>9)
    {
        res=repros(sum);
        if(res>9)
        {
            res=repros(res);
        }
        else if(res==1)
        {
            System.out.println("maagic number");
        }
        else
        {
            System.out.println("not");
        }
    }
    else
    {
        if(sum==1)
        {
            System.out.println("magic");
        }
        else
        {
            System.out.println("not magic");
        }
    }
}
public static int repros(int n)
{
    int result=0;
    while(n>0)
    {
        int rem=n%10;
        result+=rem;
        n/=10;
    }
    return result;
}
}