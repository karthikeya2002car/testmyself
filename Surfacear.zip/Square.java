import java.util.Scanner;

public class Square {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number:");
        int s,d,sum=0;
        for(int n=sc.nextInt();n>0;)
        {
            s=n%10;
            d=s*s;
            sum+=d;
            n/=10;
        }
        System.out.println(sum);
    }
    
}
