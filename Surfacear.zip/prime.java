import java.util.Scanner;

class prime {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);//used to take input
        System.out.println("enter the n value");
        int n=sc.nextInt();//enter the integer value as input
        boolean a=true;//by default keep true,if the return value is not prime then cahnge to false...
        sc.close();
        for(int i=2;i<n/2;i++)
        {
            if(n%i==0)//checking for non-primes..
            {//or if "if condition executes"boolean value is updated to false(i.e the value is not prime)...
                a=false;
                System.out.println("not prime");
                break;
            }
        }
        if(n==0 | n==1)//checking if the number is equal to 0 or 1,if yes then again boolean value is updated to false...
        {
            System.out.println("not prime");
        }
        if(a) System.out.println("prime");//if all the above if conditons will not execute then the boolean value is ture by default 
        //so the returned value is prime.
        /* this is because we checked all the possiblites find the non-prime numbers first and all the above conditions are failed then
         * last condition is automatically true...*/
}
}
