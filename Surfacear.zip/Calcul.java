import java.util.Scanner;
class Calcul {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int num1=sc.nextInt();
        int num2=sc.nextInt();
        String line=sc.next();
        sc.close();
        if (line =="add")
        {
            int add=Calcul.add(num1,num2);
            System.out.println("the sum is " +add);
        }
        if (line == "sub")
        {
            int sub=Calcul.sub(num1,num2);
            System.out.println("the sub is " +sub);
        }
        if (line == "mul")
        {
            int mul=Calcul.mul(num1,num2);
            System.out.println("the mul is " +mul);
        }
        if(line == "div")
        {
            Float div=(float) Calcul.div(num1,num2);
            System.out.println("the div is " +div);
        }
    }
    public static int add(int a,int b)
    {
        int ad=a+b;
        return ad;
    }
    public static  int sub(int a,int b)
    {
        int su=a-b;
        return su;
    }
    public static  int mul(int a,int b)
    {
        int mu=a*b;
        return mu;
    }
    public static Float div(float a,float  b)
    {
        Float di=a/b;
        return di;
    }
}
