import java.util.Scanner;

class sumpatt {
    public static void main(String[] args)
    { 
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        sc.close();
        for(int i=1;i<=n;i++)
        {
            if(i%2==0)
            {
                int k=i*n;//n is multiplied with even numbers to get 10,20,30,... values as a start values.
                for(int j=1;j<=n;j++){//used to run the loop for n times only "b=no operatio is done here".
                System.out.print(k+"\t");//just printing the k value for loop time no relation b/w loop and condition,decrement k and print.
                k--;
                }
        }
        else
        {
            int k=((i-1)*n)+1;//"PLEASE FIND THE OTHER WAY BY YoUR OWN".
            for(int j=1;j<=n;j++)//just looping.
            {
                System.out.print(k+"\t");//printing the incremented k value.
                k++;
            }
        }
            System.out.println();
        }
    
}
}
