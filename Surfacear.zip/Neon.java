import java.util.Scanner;
class Neon {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int copy=n,d=0,sum=0,i=1;
        d=n*n;
        sc.close();
        while(d!=0)
        {
            i=d%10;
            sum+=i;
            d/=10;
        }
        if(sum==copy)
        {
            System.out.println("Neon number");
        }
        else
        {
            System.out.println("Not neon number");
        }
    }
    
}
