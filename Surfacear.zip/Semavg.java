import java.util.Scanner;
class Semavg {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("please enter the semister marks in sequence of as follows: ");
        System.out.println(calculateAverage(sc.nextDouble(), sc.nextDouble(), sc.nextDouble(),sc.nextDouble(), sc.nextDouble(), 
        sc.nextDouble(),sc.nextDouble() ,sc.nextDouble()));

    }
    public static double calculateAverage(double sem1,double sem2,double sem3,double sem4,double sem5,double sem6,double sem7,double sem8)
    {
        double avg=(sem1+sem2+sem3+sem4+sem5+sem6+sem7+sem8)/8;
        return avg;
    }
    
}
