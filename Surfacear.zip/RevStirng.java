public class RevStirng {
    public static void main(String[] args) {
        
        String s1="aaabbbccc",s2="";
        /*for(int i=0;i<=s1.length()-1;i++)
        {
            for(int j=s1.length()-1;j>=0;j--)
            {
                s2=s1.replace(s1.charAt(i),s1.charAt(j));
            }
        }
        System.out.println(s2);*/
        char ch;
        for(int i=0;i<s1.length();i++)
        {
            ch=s1.charAt(i);
            s2=ch+s2;
        }
        System.out.println(s2);
    }
}
