public class no {
    public static void main(String[] args) {
        int[] a={5,2,4,0,7};
        int sum=0,d=5;
        for(int i=0;i<a.length-2;i++)
        {
            for(int j=i+1;j<a.length-1;j++)
            {
                for(int k=j+1;k<a.length;k++)
                {
                    sum+=a[i]+a[j]+a[k];

                    if(sum%d==0)
                    {
                        System.out.println(a[i]+" "+a[j]+" "+a[k]);
                    }
                }
            }
        }  
    }
}