public class AddBin {
    public static void main(String[] args) {
        
        long n=1111111111,bin=0,i=1,n1=1101010101;
        while(n>0 & n1>0)
        {
            long rem=n%10;
            long rem1=n1%10;
            bin=bin+rem*i+rem1*i;
            i=i*2;
            n/=10;
            n1/=10;
        }
        System.out.println(bin);
    }
    
}
