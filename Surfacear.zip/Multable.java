import java.util.Scanner;

public class Multable {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("enter the n value: ");
        int n=sc.nextInt();
        int mul=1;
        sc.close();
        for(int i=1;i<=10;i++)
        {
            mul=n*i;
            System.out.println(n+" x "+i+" = "+mul);
        }
}
}