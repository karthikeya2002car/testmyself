import java.util.Scanner;

class haltri {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int d=1;
        sc.close();
        for(int i=1;i<=n;i++)
        {
             for(int j=1;j<=n-i;j++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=d;j++)
            {
                if(i==n|j==1 | j==d){
                System.out.print("*");
                }
                else
                {
                    System.out.print("-");
                }
            }
            d+=2;
            System.out.println();
        }
    
}
}
