class Diagnum {
    public static void main(String[] args)
    {
        int n=5,x=n+1;
        for(int i=1;i<=n;i++)
        {
            for(int j=x;j<=n;j++)
            {
                System.out.print(j);
            }
            int k;
            for(k=1;k<=n+1-i;k++)
            {
                System.out.print(k);
            }
            x=k-1;
            System.out.println();
        }
    }
    
}
