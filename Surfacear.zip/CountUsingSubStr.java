public class CountUsingSubStr {
    public static void main(String[] args) {
        //write without seeing.......
    }
}
