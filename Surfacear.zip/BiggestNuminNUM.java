class InvalidNumberException extends Exception{

}
public class BiggestNuminNUM {
    
    public static void main(String[] args) {
        int num=234954,temp=0;
        if(num<100)
        {
            try {
                throw new InvalidNumberException();
            } catch (InvalidNumberException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        while(num>0)
        {
            int rem=num%1000;
            if(temp>rem)
            {
                System.out.println(temp);
                break;
            }
            temp=rem;
            num/=100;
        }

    }
}
