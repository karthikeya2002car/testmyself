public class VowelsInString {
    public static void main(String[] args) {
        String s1="kajjikayeee";
        String s2="aeiou";
        int count=0;
        for(int i=0;i<=s1.length()-1;i++)
        {
            for(int j=0;j<=s2.length()-1;j++)
            {
                if(s1.charAt(i)==(s2.charAt(j)))
                {
                    count++;
                }
            }
        }
        System.out.println(count);
    }
}
