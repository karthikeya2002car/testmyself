import java.util.Scanner;
class eveodd {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number:");
        int s;
        int sum=0;
        int sum1=0;
        sc.close();
        for (int n=sc.nextInt();n>0;)
        {
            s=n%10;
            System.out.println(s);
            if(s%2==0)
            {
                sum+=s;
                System.out.println(s+"is even and the sum is: "+sum);
            }
            if(s%2==1)
            {
                sum1+=s;
                System.out.println(s+"is odd and the sum is: "+sum1);  
            }
            n/=10;
        }
    }
    
}
